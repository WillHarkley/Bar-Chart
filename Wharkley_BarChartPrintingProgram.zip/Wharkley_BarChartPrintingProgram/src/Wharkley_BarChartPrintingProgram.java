import java.util.Scanner;

public class Wharkley_BarChartPrintingProgram {

	public static void main(String[] args) {
		
		int num[] = new int[5];
		
		Scanner input = new Scanner(System.in);		
		
		for (int i = 0; i <= 5; i++)
		{
			System.out.print("Enter an integer between 1 and 30 ");
			num[i] = input.nextInt();
		
			for (int x = 0; x < num[i]; x++) 
			{
				System.out.print("*");
			}
			
			System.out.println();
		}
	}
}